# Database Import Instructions

## Current Status
- Schema migration: ✅ Complete (40 tables)
- Database: erp_merchandiser
- User: erp_user
- Host: localhost:5432

## Dump Files Available
- schema-only-dump-*.sql (Schema structure)
- jobs-data-only-dump-*.sql (Job data)

## Import Process

### Option 1: Import Jobs Data Only (Recommended)
If you have a jobs-data-only dump:
```bash
# Linux/WSL
./scripts/import-jobs-data.sh dumps/jobs-data-only-dump-*.sql

# Windows
scripts\import-jobs-data.bat dumps\jobs-data-only-dump-*.sql
```

### Option 2: Import Full Database
If you have a complete dump:
```bash
docker exec -i erp-postgres psql -U erp_user -d erp_merchandiser < dumps/complete-dump.sql
```

### Option 3: Import Schema and Data Separately
1. Import schema (if needed):
   ```bash
   docker exec -i erp-postgres psql -U erp_user -d erp_merchandiser < dumps/schema-only-dump-*.sql
   ```

2. Import data:
   ```bash
   docker exec -i erp-postgres psql -U erp_user -d erp_merchandiser < dumps/jobs-data-only-dump-*.sql
   ```

## Verification
After import, verify data:
```bash
docker exec erp-postgres psql -U erp_user -d erp_merchandiser -c "SELECT COUNT(*) FROM job_cards;"
docker exec erp-postgres psql -U erp_user -d erp_merchandiser -c "SELECT COUNT(*) FROM prepress_jobs;"
```

